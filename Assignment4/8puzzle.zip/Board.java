import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdIn;
import java.util.Stack;
import java.lang.Math;

public class Board {
    private int N; 
    private int[][] blkArray; 
    private int indexZeroi; 
    private int indexZeroj;

    public Board(int[][] blocks)           // construct a board from an N-by-N array of blocks
    {
        N = blocks.length; 
        blkArray = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
            {
                blkArray[i][j] = blocks[i][j];
                if (blocks[i][j] == 0) 
                {
                    indexZeroi = i; 
                    indexZeroj = j;
                }
            }
    }
                                           // (where blocks[i][j] = block in row i, column j)
    public int dimension()                 // board dimension N
    {
        return N; 
    }

    public int hamming()                   // number of blocks out of place
    {
        int numOutofPlace = 0; 
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                if(blkArray[i][j] != 0 && blkArray[i][j] != i * N + j + 1)
                    numOutofPlace++;
            }

        }
        return numOutofPlace;
    }

    public int manhattan()                 // sum of Manhattan distances between blocks and goal
    {
        int manhattanSum = 0; 
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                if (blkArray[i][j] != 0)
                {
                    if(blkArray[i][j] % N == 0)
                    {
                        manhattanSum = manhattanSum + Math.abs(N - 1 - j) + Math.abs(blkArray[i][j]/ N - 1 -i); 
                    }
                    else 
                    manhattanSum = manhattanSum + Math.abs(blkArray[i][j] % N - 1 - j) + Math.abs(( blkArray[i][j] - blkArray[i][j] % N )/ N - i); 
                }
                

            }
        }
        return manhattanSum; 
    }

    public boolean isGoal()                // is this board the goal board?
    {
        int flag = 0; 
        int i = 0; 
        while(i < N && flag == 0)
        {
            int j = 0; 
            while (j < N && flag == 0)
            {
                if (blkArray[i][j] != 0 && blkArray[i][j]!= i * N + j + 1) flag = 1;
                j++;  
            }
            i++;
        }

        return flag == 0; 
    }

    public Board twin()                    // a board that is obtained by exchanging any pair of blocks
    {
        int r1 = 0; 
        int r2 = 0; 
        int i1 = 0; 
        int j1 = 0; 
        int i2 = 0; 
        int j2 = 0;
        int temp;

        Board arrayTwin = new Board(blkArray);

        while ( r2 == r1 || arrayTwin.blkArray[i1][j1] == 0 || arrayTwin.blkArray[i2][j2] == 0)
        {
            r1 = StdRandom.uniform(N * N); 
            r2 = StdRandom.uniform(N * N);
            i1 = (r1 - r1 % N) / N;
            j1 = r1 % N;
            i2 = (r2 - r2 % N) / N;
            j2 = r2 % N;
        }
        temp = arrayTwin.blkArray[i1][j1]; 
        arrayTwin.blkArray[i1][j1] = arrayTwin.blkArray[i2][j2];
        arrayTwin.blkArray[i2][j2] = temp;
        return arrayTwin;
    }

    public boolean equals(Object y)        // does this board equal y?
    {
        if ( y == this) return true; 
        if ( y == null) return false; 
        if (y.getClass() != this.getClass()) return false; 
        Board that = (Board) y; 
        if(this.dimension() != that.dimension()) return false;
        int flag = 0; 
        int i = 0; 
        while(i < N && flag == 0)
        {
            int j = 0; 
            while (j < N && flag == 0)
            {
                if (blkArray[i][j]!= that.blkArray[i][j]) flag = 1;
                j++;  
            }
            i++;
        }
        return flag == 0; 
    }

    public Iterable<Board> neighbors()     // all neighboring boards
    {
        Stack<Board> allneighbors = new Stack<Board>();
        Board tempneighbor = new Board(blkArray);
        //Board tempneighbor2 = new Board(blkArray);
        //Board tempneighbor3 = new Board(blkArray);
        //Board tempneighbor4 = new Board(blkArray); 
        if(indexZeroj != 0) 
            {
                tempneighbor.blkArray[indexZeroi][indexZeroj] = blkArray[indexZeroi][indexZeroj - 1]; 
                tempneighbor.blkArray[indexZeroi][indexZeroj - 1] = 0; 
                allneighbors.push(tempneighbor); 
                tempneighbor = new Board(blkArray);
            }
        if(indexZeroj != N-1)
            {
                tempneighbor.blkArray[indexZeroi][indexZeroj] = blkArray[indexZeroi][indexZeroj + 1]; 
                tempneighbor.blkArray[indexZeroi][indexZeroj + 1] = 0; 
                allneighbors.push(tempneighbor);
                tempneighbor = new Board(blkArray);

            }
        if(indexZeroi != 0)
            {
                tempneighbor.blkArray[indexZeroi][indexZeroj] = blkArray[indexZeroi - 1][indexZeroj]; 
                tempneighbor.blkArray[indexZeroi - 1][indexZeroj] = 0; 
                allneighbors.push(tempneighbor); 
                tempneighbor = new Board(blkArray);
            }
        if(indexZeroi != N-1)
            {
                tempneighbor.blkArray[indexZeroi][indexZeroj] = blkArray[indexZeroi + 1][indexZeroj]; 
                tempneighbor.blkArray[indexZeroi + 1][indexZeroj] = 0; 
                allneighbors.push(tempneighbor); 
                tempneighbor = new Board(blkArray);
            }
        return allneighbors; 

    }

    public String toString()               // string representation of this board (in the output format specified below)
    {
        StringBuilder s = new StringBuilder();
        s.append(N + "\n");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                s.append(String.format("%2d ", blkArray[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }

    public static void main(String[] args) // unit tests (not graded)
    {}
}